Changes in repmgr 4
===================

This document has been integrated into the main `repmgr` documentation
and is now located here:

> [Release notes](https://repmgr.org/docs/current/release-4.0.html)
