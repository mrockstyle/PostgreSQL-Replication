FAQ - Frequently Asked Questions about repmgr
=============================================

The repmgr 4 FAQ is located here: [repmgr FAQ (Frequently Asked Questions)](https://repmgr.org/docs/current/appendix-faq.html "repmgr FAQ")

The repmgr 3.x FAQ can be found here:

    https://github.com/2ndQuadrant/repmgr/blob/REL3_3_STABLE/FAQ.md

Note that repmgr 3.x is no longer supported.
